extends CharacterBody2D
@export var acceleration: int = 5
@export var speed: int = 80

func _physics_process(delta: float) -> void:
	handle_input()
	move_and_slide()
	
	
func handle_input() -> void: 
	var direction = Input.get_axis("ui_left", "ui_right") 
	if direction == 0: 
		velocity.x = move_toward(velocity.x, 0, acceleration)
	else:
		velocity.x = move_toward(velocity.x, speed * direction, acceleration)
		
